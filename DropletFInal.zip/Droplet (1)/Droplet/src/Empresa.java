/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joaomuniz
 */
public class Empresa {
    String nome;
    private String slogan;
    private String desc;
    
    Empresa(String nome, String slogan, String desc){
        this.nome = nome;
        this.slogan = slogan;
        this.desc = desc;
    }
}
