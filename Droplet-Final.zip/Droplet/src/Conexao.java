
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joaomuniz
 */
public class Conexao {
    
        Connection con;
    
    public boolean conecta(String local, String banco, String usuario, String senha)
    {
        boolean retorno = false;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://" + local + "/" + banco,usuario, senha);
            retorno = true;
        }
        catch (ClassNotFoundException e){
            System.err.println("Erro de conexão:\n" + e);
        }
        catch (SQLException e){
            System.err.println("Erro de conexão:\n" + e);
        }
        return retorno;
    }
    
    public boolean insere(String tabela, String codigo, String desc, String preco, String nome){
        boolean retorno = false;
    try {
        PreparedStatement stmt = (PreparedStatement) this.con.prepareStatement("insert into " + tabela + " (CodRef,descricao,preco,nome) values (' " + codigo + " ',' " + desc + " ', '" + preco +"', '" + nome +"');");
        stmt.execute();
        stmt.close();
        retorno = true;
    } 
    catch (SQLException ex) {
        //System.err.println("Erro INSERT: " + ex);
        JOptionPane.showMessageDialog(null, "Cadastro Já Efetuado");
    }
        return retorno;
    }
    
    public ResultSet consulta(String consulta){
        ResultSet rs = null;
        try{
            PreparedStatement stmt = (PreparedStatement) this.con.prepareStatement(consulta);
            rs = stmt.executeQuery();
        }
        catch (Exception e){
            System.err.println("Erro CONSULTA: " +e);
        }
        return rs;
    }
    
    public boolean atualiza(String tabela, String campos, String condicao){
        boolean retorno = false;
        try{
            PreparedStatement stmt = (PreparedStatement) this.con.prepareStatement("update " + tabela + " set " + campos + " where " + condicao);
            stmt.executeUpdate();
            stmt.close();
            retorno = true;
        }
        catch (SQLException ex){
            System.err.println("Erro UPDATE: " + ex);
        }
        return retorno; 
    }
    
    public boolean exclui(String tabela, String nome){
        boolean retorno = false;
        try{
            PreparedStatement stmt = (PreparedStatement) this.con.prepareStatement("delete from " + tabela + " where nome = ' " + nome + " '");
            stmt.executeUpdate();
            stmt.close();
            retorno = true;
        }
        catch (SQLException ex){
            System.err.println("Error DELETE:" + ex);
        }
        return retorno;
    }
        
        
}
